var data = [{
    name: '高迪出生',
    year: '1852',
    addr: '塔拉戈那',
    type: 'img',
    class:"_1852"
}, {
    name: '高迪获天才称号',
    year: '1878',
    addr: '巴塞罗那大学',
    type: 'img',
     class:"_1878"
}, {
    name: '马塔罗现代艺术馆',
    year: '1877',
    addr: '塔拉戈那',
    type: 'img',
     class:"_1877"
}, {
    name: '文森之家',
    year: '1878',
    addr: '巴塞罗那',
    type: 'img',
     class:"_1878_2"
}, {
    name: '随性楼',
    year: '1883',
    addr: '科米利亚斯',
    type: 'img',
     class:"_1883"
}, {
    name: '圣家族大教堂',
    year: '1883',
    addr: '巴塞罗那',
    type: 'url',
     class:"_1883_2"
}, {
    name: '桂尔庄园',
    year: '1884',
    addr: '巴塞罗那',
    type: 'img',
     class:"_1884"
}, {
    name: '桂尔宫',
    year: '1885',
    addr: '巴塞罗那',
    type: 'img',
     class:"_1885"
}, {
    name: '主教宫',
    year: '1887',
    addr: '阿斯托加',
    type: 'img',
     class:"_1887"
}, {
    name: '特雷西那学校',
    year: '1887',
    addr: '巴塞罗那',
    type: 'img',
     class:"_1887_2"
}, {
    name: '世博会',
    year: '1888',
    addr: '巴塞罗那',
    type: 'img',
     class:"_1888"
}, {
    name: '博得格斯之家',
    year: '1891',
    addr: '莱昂',
    type: 'img',
     class:"_1891"
}, {
    name: '高迪酒窖',
    year: '1895',
    addr: '西切斯',
    type: 'img',
     class:"_1895"
}, {
    name: '桂尔纺织村教堂',
    year: '1898',
    addr: '圣科洛马',
    type: 'video',
     class:"_1898"
}, {
    name: '卡尔维特之家',
    year: '1898',
    addr: '巴塞罗那',
    type: 'img',
     class:"_1898_2"
}, {
    name: '桂尔公园',
    year: '1899',
    addr: '巴塞罗那',
    type: 'img',
     class:"_1899"
}, {
    name: '美景楼',
    year: '1900',
    addr: '巴塞罗那',
    type: 'video',
     class:"_1900"
}, {
    name: '阿蒂加斯花园',
    year: '1902',
    addr: '拉波夫拉',
    type: 'img',
     class:"_1902"
}, {
    name: '山区躲雨鹏',
    year: '1902',
    addr: '拉波夫拉',
    type: 'img',
     class:"_1902_2"
},
 {
    name: '马洛卡大教堂',
    year: '1902',
    addr: '马洛卡岛',
    type: 'img',
     class:"_1902_3"
}, {
    name: '巴特罗之家',
    year: '1904',
    addr: '巴塞罗那',
    type: 'img',
     class:"_1904"
}, {
    name: '米拉之家',
    year: '1905',
    addr: '巴塞罗那',
    type: 'video',
     class:"_1905"
}, {
    name: '高迪死亡',
    year: '1926',
    addr: '巴塞罗那',
    type: 'img',
     class:"_1926"
}]